const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');

const tenantProfileSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            default: uuidV4,
            hashKey: true,
        },
        //tenant id 
        tenant_id: {
            type: String
        },
        address1: {
            type: String,
        },
        address2: {
            type: String,
        },
        address3: {
            type: String,
        },
        city: {
            type: String,
        },
        state: {
            type: String,
        },
        country: {
            type: String,
        },
        zip_code: {
            type: String,
        },
        mobile_number: {
            type: String,
        },
        email: {
            type: String,
        },
        remarks: {
            type: String,
        },
        logo: {
            type: String
        },
        administrative_policies: {
            type: String
        },
        branch: {
            type: String
        },
        branch_code: {
            type: String
        },
        fax_number: {
            type: String
        },
        founder: {
            type: String
        },
        founding_date: {
            type: String
        },
        found_location: {
            type: String
        },
        geo_lat: {
            type: String
        },
        geo_lng: {
            type: String
        },
        human_resource_management_policies: {
            type: String
        },
        information_management_policies: {
            type: String
        },
        legal_name: {
            type: String
        },
        medicine_policies: {
            type: String
        },
        no_of_employees: {
            type: String
        },
        providing_care_policies: {
            type: String
        },
        tax_id: {
            type: String
        },
        updated_by: {
            type: String
        },
    },

    {
        saveUnknown: true,
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const tenantProfile = dynamoose.model('tenant_profile', tenantProfileSchema, { create: true });
module.exports = tenantProfile