const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');

const specialtyMasterSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            default: uuidV4,
            hashKey: true,
        },
        name: {
            type: String,
        },
        is_active: {
            type: Boolean,
        },
        is_deleted: {
            type: Boolean,
        },

        tenant_id: {
            type: String,
        },
        user_id: {
            type: String,
        },
        created_by: {
            type: String
        },
        updated_by: {
            type: String
        },
    },

    {
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const specialtyMaster = dynamoose.model('specialty_master', specialtyMasterSchema, { create: true });
module.exports = specialtyMaster