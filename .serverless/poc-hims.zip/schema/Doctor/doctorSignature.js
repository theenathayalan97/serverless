const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid')

const signatureSchema = new dynamoose.Schema({
    uuid: {
        type : String, hashKey:true, default: uuidv4
    },
    is_deleted: {
        type: Boolean, required: true
    },
    signature: {
        type: String, required: true
    },
    //foreign key
    tenant_id: {
        type: String, required: true
    },
    created_by: {
        type: String, required: true
    },
    updated_by: {
        type: String, required: true
    },
},
    {
        timeStamps: true
    })


module.exports = dynamoose.model('signature', signatureSchema)