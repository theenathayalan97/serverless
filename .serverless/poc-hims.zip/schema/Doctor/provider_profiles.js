const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid');

const providersProviderProfilesSchema = new dynamoose.Schema({
    uuid:
    {
        type: String,
        default: uuidv4,
        hashKey: true
    },
    details: {
        type: Object,
       
    },
    set_default: {
        type: Boolean, required: false
    },
    created_by: {
        type: String, required: false
    },
    updated_by: {
        type: String, required: false
    },
    profile_name: {
        type: String, required: false,
    },
    // foreign key
    provider_id: {
        type: String, required: false
    },
    tenant_id: {
        type: String, required: false
    }
},
    {
        timeStamps: true,
        saveUnknown: true
    })

module.exports = dynamoose.model('provider_profiles', providersProviderProfilesSchema)