const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid')

const availableSchema = new dynamoose.Schema({
    uuid: {
        type : String, hashKey:false, default: uuidv4
    },
    start_Date: {
        type: String
    },
    end_Date: {
        type: String
    },//"10:30"
    schedule_starttime:{
        type: String
    },schedule_endtime:{
        type: String
    },//"10:00"
    repeat_availability: {
        type: Boolean,
    },
    day_of_week: {
        type: String
    },
    is_active: {
        type: Boolean
    },
    is_deleted: {
        type: Boolean
    },
    //foreign key
    created_by: {
        type: String
    },
    updated_by: {
        type: String
    },
    provider_id: {
        type: String
    },
},
    {
        timeStamps: false
    })

module.exports = dynamoose.model('Available', availableSchema)