const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid');

const providerProfileSchema = new dynamoose.Schema({
    uuid:
        { type: String, default: uuidv4 ,hashKey: true,},
    name: {
        type: String,  required: false, unique: true
    },
    description: {
        type: String, required: false
    },
    profile_view: {
        type: String, required: false
    },
    answer_document_name: {
        type: String, required: false
    },
    questions_document_name: {
        type: Boolean, required: false
    },
    doctype: {
        type: Boolean, required: false
    },
    channels: {
        type: String, required: false
    },
    updated_required: {
        type: Boolean, required: false
    },
    is_deleted: {
        type: Boolean, required: false
    },
    default_required: {
        type: Boolean, required: false
    },
    mandatory: {
        type: Boolean, required: false
    },
    //foreign key
    created_by: {
        type: String, required: false
    },
    updated_by: {
        type: String, required: false
    },
    attachment_required: {
        type: Boolean, required: false
    },
},
    {
        timeStamps: true
    })

module.exports = dynamoose.model('provider_profile_master', providerProfileSchema)