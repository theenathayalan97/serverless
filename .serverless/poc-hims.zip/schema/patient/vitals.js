const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid')

const vitals = new dynamoose.Schema({
    uuid:
        { type: String,hashKey: true, default: uuidv4 },
    blood_pressure_systolic:
        { type: String, required: true },
    blood_pressure_diastolic:
        { type: String, required: true },
    height:
        { type: String, required: true },
    weight:
        { type: String, required: true },
    temperature:
        { type: String, required: true },
    pulse_rate:
        { type: String, required: true },
    bmi:
        { type: String, required: true },
    waist_circumference:
        { type: String, required: false },
    triglycerides:
        { type: String, required: false },
    fast_blood_glucose:
        { type: String, required: false },
    SPO2:
        { type: String, required: false },
    is_active:
        { type: String, required: false },
    is_deleted:
        { type: String, required: false }

}, {
    timeStamps: true
})

module.exports = dynamoose.model('vital', vitals, { create: true })