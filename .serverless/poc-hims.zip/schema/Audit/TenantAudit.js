const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');

const tenantAuditSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            default: uuidV4,
            hashKey: true,
        },
        name: {
            type: String,
        },
        domain: {
            type: Array,
            // "schema": [String],
        },
        is_deleted: {
            type: Boolean,
        },
        //foreign key
        super_admin_id: {
            type: String
        },
        created_by: {
            type: String
        },
        updated_by: {
            type: String
        },
    },

    {
        saveUnknown: true,
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const tenantAudit = dynamoose.model('tenant_audit', tenantAuditSchema, { create: true });
module.exports = tenantAudit