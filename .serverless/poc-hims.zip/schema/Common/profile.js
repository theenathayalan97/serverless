const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');

const profileSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            default: uuidV4,
            
        },
        otp: {
            type: String,
        },
        is_active: {
            type: Boolean,
        },
        is_deleted: {
            type: Boolean,
        },
        marital_status: {
            type: String
        },
        dob: {
            type: String
        },
        emergency_contact: {
            type: String
        },
        Profile_photo: {
            type: String
        },
        gender: {
            type: String
        },
        language: {
            type: String
        },
        age: {
            type: Number
        },
        user_id: {
            type: String,
            hashKey: true,

           
        },
        tenant_id: {
            type: String
        },
        updated_by: {
            type: String
        },
    },

    {
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const profile = dynamoose.model('profile', profileSchema, { create: true });
module.exports = profile