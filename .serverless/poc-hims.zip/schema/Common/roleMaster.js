const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidv4 } = require('uuid');
const roleMaster = new dynamoose.Schema(
  {
    uuid: {
      type: String,
      default: uuidv4,
      hashKey: true,
      unique:true
    },
    role_name: {
      type: String,
      required:true,
    },
    is_active: {
      type: Boolean,
      
    },
    is_deleted: {
      type: Boolean,
      
    },
    created_by: {
      type: String,
    },
    updated_by: {
      type: String,
    },
},
  {
    consistentRead: true,
    timeStamps: true
  }
);

// Create a DynamoDB table using the defined schema
const roleMasterModel = dynamoose.model('roleMaster', roleMaster);
module.exports = roleMasterModel