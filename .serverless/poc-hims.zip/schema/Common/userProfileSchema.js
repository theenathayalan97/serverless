//const dynamoose = require('../../dbConfig/dynamodb')
const dynamoose = require('dynamoose');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const userSchema = new dynamoose.Schema(
  {
    uuid: {
      type: String,
      default: uuidv4,
      hashKey: true,
      unique: true,

    },
    first_name: {
      type: String,
      required: true
    },
    last_name: {
      type: String,
      required: true
    },
    email: {
      type: String,
      require: true,
      unique: true,
      validate: function (value) {
        return /\S+@\S+\.\S+/.test(value);
      },message: 'Email must be a valid email address'
    },
    phone_number: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
      exclude: true, // Exclude the password attribute from query results
    },
    
    verified: {
      type: Boolean,
    },
    is_active: {
      type: Boolean,
    },
    is_delete: {
      type: Boolean,
    },
    is_active: {
      type: Boolean,
    },
    last_login: {
      type: String,
    },
    submitted: {
      type: Boolean,
    },
    resubmitted: {
      type: Boolean,
    },
    created_by: {
      type: String,
    },
    updated_by: {
      type: String,
    },
    role: {
      type: String,
      require: true
    },
    tenant_id: {
      type: String,
    },
  },
  {
    timeStamps: true
  }
);

// Create a DynamoDB table using the defined schema
const Product = dynamoose.model('users', userSchema, { create: true });
module.exports = Product