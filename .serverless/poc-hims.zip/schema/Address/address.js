const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');
const addressSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            hashKey: true,
            default: uuidV4
        },
        address_type: {
            type: String,
        },
        address1: {
            type: String,
        },
        address2: {
            type: String,
        },
        city: {
            type: String,
        },
        state: {
            type: String,
        },
        country: {
            type: String,
        },
        zip_code: {
            type: String,
        },
        primary_address: {
            type: String,
        },
        Secondary_phone: {
            type: String,
        },
        secondary_email: {
            type: String,
        },
        is_active: {
            type: Boolean,
        },
        is_deleted: {
            type: Boolean,
        },

        //foreign key
        user_id: {
            type: String,
        },
        tenant_id: {
            type: String,
        },
        created_by: {
            type: String
        },
        updated_by: {
            type: String,
        },
    },

    {
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const address = dynamoose.model('address', addressSchema, { create: true });
module.exports = address