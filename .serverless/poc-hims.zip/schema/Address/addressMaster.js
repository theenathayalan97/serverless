const dynamoose = require('../../dbConfig/dynamodb')
const { v4: uuidV4 } = require('uuid');

const addressMasterSchema = new dynamoose.Schema(
    {
        uuid: {
            type: String,
            hashKey: true,
            default: uuidV4
        },
        place: {
            type: String,
        },
        sub_district: {
            type: String,
        },
        district: {
            type: String,
        },
        state: {
            type: String,
        },
        country: {
            type: String,
        },
        primary_address: {
            type: String,
        },
        is_active: {
            type: Boolean,
        },
        is_deleted: {
            type: Boolean,
        },
    },

    {
        timestamps: true, // Add createdAt and updatedAt fields
    }
);

// Create a DynamoDB table using the defined schema
const addressMaster = dynamoose.model('address_master', addressMasterSchema, { create: true });
module.exports = addressMaster