const express = require('express')
const route = express()
const SuperAdminController = require('../../controller/superAdmin/superAdmin.controller');
const UserController = require('../../controller/common/user/user.controller');
const AdminController = require('../../controller/common/admin/admin.controller');
const UserSignUpValidation = require('../../middleWare/validation/user/userSignupValdiation')
const AdminSignUpValidation = require('../../middleWare/validation/superAdmin/superAdminValdiation')
const { VerifyToken, Authorize } = require('../../middleWare/auth');
const userController = require('../../controller/common/user/user.controller');

route.post(`/super-admin-signup`, AdminSignUpValidation.AdminSignUpPlayLoadValidation, SuperAdminController.SuperAdminSignUp);
route.post(`/super-admin-login`, SuperAdminController.SuperAdminLogin);
route.post(`/signup`, VerifyToken, Authorize(['admin', 'super_admin', 'helpdesk']), UserController.SignUp);
route.post(`/patient-signup`,  UserController.PatientSignUp);
route.post(`/login`, UserController.login);
route.put(`/change-password`, VerifyToken, Authorize(['admin', 'super_admin','helpdesk']), UserSignUpValidation.changePasswordValidation, UserController.changePassword);
route.put(`/approve-doctor`, VerifyToken, Authorize(['admin', 'super_admin',]), AdminController.ApproveDoctorDocument);
route.put(`/document-submitted`, VerifyToken, Authorize(['doctor']), UserController.DoctorDocumentIsSubmitted);
route.get(`/get-user`, VerifyToken, Authorize(['admin', 'super_admin', 'helpdesk','super_admin','doctor']), UserController.GetUserById);
route.get(`/get-all-document-submitted`, VerifyToken, Authorize([ 'admin', 'super_admin']), UserController.GetAllDocumentSubmittedByStatus);
route.get(`/get-users-by-created-by`, VerifyToken, Authorize([ 'helpdesk','admin', 'super_admin']), UserController.GetUsersByCreatedBy);
route.put(`/update-profile`, VerifyToken, Authorize([ 'helpdesk','admin', 'super_admin','patient','doctor']), UserController.UpdateProfile);
route.get(`/get-by-role`, VerifyToken, Authorize([ 'helpdesk','admin', 'super_admin','patient','doctor']), UserController.GetAllUserByRole);
route.get(`/forget-password`, userController.forgetPassword)

module.exports = route