
var passwordValidator = require('password-validator');
// Create a schema
var pvalid = new passwordValidator();
const databaseConnection = require(`../../../utilities/databaseConfig`)
const Repo = databaseConnection.Repository()
const Repository = require('../../repository/' + Repo)

pvalid
    .is().min(8)                                    // Minimum length 8
    .is().max(20)                                  // Maximum length 100
    .has().uppercase()                              // Must have uppercase letters
    .has().lowercase()                              // Must have lowercase letters
    .has().digits(1)                                // Must have at least 2 digits
    .has().not().spaces()                           // Should not have spaces
    .has().symbols(1, ['@'])//special chart
    .is().not().oneOf(['Passw0rd', 'Password123']);

function response(res, statuscode, message,) {
    return res.status(statuscode).json(message);
}
function originMissing(req, res, next) {
    if (req.headers.origin == '' || req.headers.origin == undefined) {
        return res.status(401).json({ message: 'origin is missing or invalid' });
    }
    next()
}

function phoneNumberValidation(phone_number) {
    const phoneRegex = /^(?:\+?\d{1,3}[\s-])?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
    console.log(phone_number.length <= 9, phone_number.length >= 11, phoneRegex.test(phone_number) !== true, phone_number.charAt(0) <= '5');
    if (phone_number.length <= 9 || phone_number.length >= 11 || phoneRegex.test(phone_number) !== true) {
        return true;
    } else {
        return false;
    }
}
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function JsonFieldValidation(channelName, documentType) {
    return async function (req, res, next) {
        var filter = {
            'tenant_id': req.tenant_id,
            'channel_name': channelName,
            'document_type': documentType,
            'document_name': req.params.name + '_answers'
        }
        const tenantJsonMaster = await axios.post('localhost:3000/api/{{localhost}}search_json?tenant_id=572f6906-3b0c-4b63-b3bc-dfdb48e242c9&channel_name=PROFILE&document_type=provider&document_name=education_answers')
        // const tenantJsonMaster = await Repository.queryItemsByAttributesAndIN('tenant_json_master', filter)
        if (tenantJsonMaster) {
            return res.status(400).json({ message: 'tenant not found', data: error.message })
        }
        let keys1 = Object.keys(tenantJsonMaster[0].details)
        let keys2 = Object.keys(req.body)
        let response = keys1.filter(item => !keys2.includes(item));
        if (response.length > 0) {
            return res.status(400).json({ message: 'these filed are invalid', data: response })
        }
        next();
    }
}

module.exports = { response, phoneNumberValidation, pvalid, validateEmail, originMissing, JsonFieldValidation }