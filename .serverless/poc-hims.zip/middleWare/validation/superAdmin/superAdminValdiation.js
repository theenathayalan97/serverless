const { response } = require('../commonValidation/validation')
const message = require('../../../constant/constants')
const { phoneNumberValidation, pvalid, validateEmail } = require('../commonValidation/validation')
class AdminSignUpValidation {
    AdminSignUpPlayLoadValidation(req, res, next) {
        try {
            if (req.body.first_name == "" || req.body.first_name == undefined) {
                return response(res, 400, { message: message.firstNameMissing })
            }
            if (req.body.email == "" || req.body.email == undefined) {
                return response(res, 400, { message: message.emailMissing })
            }
            if (req.body.phone_number == "" || req.body.phone_number == undefined) {
                return response(res, 400, { message: message.phoneNumberMissing })
            }
            if (req.body.password == "" || req.body.password == undefined) {
                return response(res, 400, { message: message.passwordMissing })
            }
            if (req.body.role == "" || req.body.role == undefined) {
                return response(res, 400, { message: message.roleMissing })
            }
            if (phoneNumberValidation(req.body.phone_number)) {
                return response(res, 400, { message: message.phoneNumberInvalid })
            }
            if (validateEmail(req.body.email) == false) {
                return response(res, 400, { message: message.EmailNotValid })
            }
            if (!pvalid.validate(req.body.password)) {
                return response(res, 400, { message: message.passwordValid })
            }
            next()
        } catch (error) {
            return res.status(400).json(error.message)
        }


    }
}

module.exports = new AdminSignUpValidation()