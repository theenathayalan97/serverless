require(`dotenv`).config();

function Repository() {
    console.log('process.env.Database', process.env.databaseConnection);
    var Repository
    if (process.env.databaseConnection == 'postgres') {
        Repository = `../../repository/postgres`
    }
    if (process.env.databaseConnection == 'dynamodb') {
        Repository = `../../repository/dynamodbRepository`
    }
    console.log('repository', Repository);
    return Repository

}

module.exports = { Repository }