const databaseConnection = require(`../../utilities/databaseConfig`)
const Repo = databaseConnection.Repository()
const Repository = require(Repo);const message = require('../../constant/constants')
const tableNames = require('../../constant/dbTablesName')


class AdminService {
    //to approve doctor by document details
    async ApproveDoctorByDocument(req, res, tableName) {

        try {
            var { resubmit, doctor_phone_number } = req.query
            var data={}
            data.phone_number= doctor_phone_number
            data.tenant_id= req.tenant_id
            var checkUser = await Repository.queryItemsByAttributesAndIN(tableName,data);
            if (checkUser.length == 0) {
                return res.status(400).json({ message: message.doctorNotFound })
            }
            var key = { 'uuid': checkUser[0].role }
            var isRole = await Repository.GetOne(key, tableNames.roleMaster);
            if (isRole.role_name != 'doctor') {
                return res.status(400).json({ message: message.doctorNotFound })
            }
            if (resubmit == "true") {
                let data = {}
                data.verified = true
                data.resubmitted = false
                console.log(data);
                const Key = {
                    'uuid': checkUser[0].uuid,
                };
                await Repository.updateMultipleFields(Key, data, tableName)
                return res.status(200).json({ message: message.approveMessage })
            }
            if (resubmit == "false") {
                let data = {}
                data.verified = false
                data.resubmitted = true
                console.log(data);
                const Key = {
                    'uuid': checkUser[0].uuid,
                };
                await Repository.updateMultipleFields(key, data, tableName)
                return res.status(200).json({ message: message.rejectMessage })
            }

        } catch (error) {
            return res.status(400).json({ message: message.errorMessage, result: error.message })
        }
    }
}

module.exports = new AdminService()