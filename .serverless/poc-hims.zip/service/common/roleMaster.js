const databaseConnection = require(`../../utilities/databaseConfig`)
const Repo = databaseConnection.Repository()
const Repository = require(Repo);
const message = require('../../constant/constants')
const tableNames = require('../../constant/dbTablesName')


class RoleMasterService {
    // to create the role 
    async createRoleService(req, res, tableName) {
        try {
            if (req.body.role_name == "" || req.body.role_name == undefined) {
                return res.status(400).json({ message: message.roleMissing })
            }
            var data = {}
            data.role_name = req.body.role_name
            var role = await Repository.ScanItemsByAttributeValue('role_name', req.body.role_name, tableName)
            console.log(role);
            if (role.length != 0) {
                return res.status(400).json({ message: message.roleExists })
            }
            var roleCreated = await Repository.create(data, tableName)
            console.log(role);
            return res.status(200).json({ message: message.createMessage, id: roleCreated.uuid })


        } catch (error) {
            return res.status(400).json({ message: message.errorMessage, error: error.message })
        }
    }
    // to get the role by id
    async getRoleById(req, res, tableName) {
        try {
            var id = req.params.id;
            var key = { 'uuid': id }
            var getRole = await Repository.GetOne(key, tableName)
            console.log(getRole);
            if (getRole) {
                const {uuid,role_name}=getRole
                var result={}
                result.uuid=uuid
                result.role_name=role_name
                return res.status(200).json({ message: message.getMessage, result: result })
            } else {
                return res.status(400).json({ message: message.role, result: message.roleNotMatch })
            }
        } catch (error) {
            return res.status(400).json({ message: message.errorMessage, result: error.message })
        }

    };
    //to update or delete role based on the query status
    async roleDeleteOrUpdate(req, res, tableName) {
        try {
            var id = req.params.id;;
            var key = { 'uuid': id }
            var getRole = await Repository.GetOne(key, tableName)
            if (!getRole) {
                return res.status(400).json({ message: message.roleNotMatch })
            }
            if (req.query.is_delete == 'true') {
                var data = {}
                data.is_active = false
                data.is_deleted = true
                var key = { "uuid": id }
                const profileUpdates = await Repository.updateMultipleFields(key, data, tableName);
                return res.status(200).json({ message: message.updateMessage, result: profileUpdates.uuid })
            }
            if (req.query.is_update === 'true') {
                var data1 = {}
                data1.role_name = req.body.role_name
                var role = await Repository.ScanItemsByAttributeValue('role_name', data1, tableName)
                console.log(role);
                if (role.length != 0) {
                    return res.status(400).json({ message: message.roleExists })
                }
                var key = { "uuid": id }
                const profileUpdates = await Repository.updateMultipleFields(key, data1, tableName);
                return res.status(200).json({ message: message.updateMessage, result: profileUpdates.uuid })
            }
        } catch (error) {
            return res.status(400).json({ message: message.errorMessage, error: error.message })
        }

    };
    // to get all role
    async getALlRole(req, res, tableName) {
        try {

            var allRole = await Repository.GetAllItems(tableName)
            return res.status(200).json({ message: 'Fetched successfully', data: allRole })

        } catch (error) {
            return res.status(400).json({ message: message.errorMessage, error: error.message })
        }

    };
}

module.exports = new RoleMasterService()