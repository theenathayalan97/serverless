const databaseConnection = require(`../../utilities/databaseConfig`)
const Repo = databaseConnection.Repository()
const Repository = require(Repo);
const { response, pvalid } = require('../../middleWare/validation/commonValidation/validation')
const message = require('../../constant/constants')
const tableNames = require('../../constant/dbTablesName')
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { jwtSign, VerifyToken } = require('../../middleWare/auth')

class SuperAdminService {
    //super Admin SignUp
    async SuperAdminSignUp(req, res, tableName) {
        try {
            var data={}
            data.phone_number=req.body.phone_number
            data.role=req.body.role
            var isUserExits = await Repository.queryItemsByAttributesAndIN(tableName, data);
            if (isUserExits.length >= 1) {
                return response(res, 400, { message: message.userExists })
            }
           
            var isRoleExits = await Repository.ScanItemsByAttributeValue('uuid', req.body.role, tableNames.roleMaster);
            if (isRoleExits.length == 0) {
                return response(res, 400, { message: message.roleNotMatch })
            }
            if (isRoleExits[0].is_active == false) {
                return response(res, 400, { message: message.roleInactive })
            }
            if (isRoleExits[0].role_name == 'super_admin') {
                try {
                    req.body.password = bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10))
                    req.body.is_active = true
                    var superAdminCreated = await Repository.create(req.body, tableName);
                    console.log(superAdminCreated,'ll');
                    var updateData = {}
                    updateData.created_by = superAdminCreated.uuid
                    updateData.updated_by = superAdminCreated.uuid
                    updateData.role = req.body.role
                    console.log(updateData);
                    const Key = {
                        'uuid': superAdminCreated.uuid,
                    };
                    await Repository.updateMultipleFields(Key, updateData, tableName);
                    return response(res, 200, { message: message.createMessage })
                } catch (error) {
                    await Repository.deleteByID(superAdminCreated.uuid, tableName);
                    return response(res, 400, { message: error.message })
                }
            } else {
                return response(res, 401, { message: message.roleNotMatch })
            }
        } catch (error) {
            return response(res, 400, { message: error.message })
        }
    }
    //super Admin Login
    async SuperAdminLogin(req, res, tableName) {
        var body = req.body
        try {
            var isUserCheck = await Repository.ScanItemsByAttributeValue('phone_number', req.body.phone_number, tableName);
            if (isUserCheck.length == 0) {
                return response(res, 400, { message: message.phoneNumberIncorrect })
            }
            var checkRole = await Repository.ScanItemsByAttributeValue('uuid', isUserCheck[0].role, tableNames.roleMaster);
            if (checkRole.length == 0 || checkRole[0].role_name != 'super_admin') {
                return response(res, 400, { message: message.superAdminAccess })
            }
            if (checkRole[0].is_active == false || checkRole[0].is_delete == false) {
                return response(res, 400, { message: message.deactivate })
            }
            // Compare passwords
            const isPasswordValid = await bcrypt.compare(body.password, isUserCheck[0].password);
            if (!isPasswordValid) {
                return response(res, 400, { message: message.phoneNumberIncorrect })
            }
            var key = { 'uuid': checkRole[0].uuid }
            const roleResponse = await Repository.GetOne(key, tableNames.roleMaster);
            if (roleResponse.length == 0) {
                return response(res, 400, { message: message.roleNotMatch })
            }
            var playLoad = { id: isUserCheck[0].uuid, phone_number: isUserCheck[0].phone_number, role: isUserCheck[0].role, role_name: roleResponse.role_name }
            var lastLogin = Date.now();
            isUserCheck[0].last_login = lastLogin.toString()
            var key={'uuid':isUserCheck[0].uuid}
            await Repository.updateOne(key, 'last_login', isUserCheck[0].last_login, tableName);
            return response(res, 200, { message: message.loginSuccess, token: jwtSign(playLoad, 432000), role: roleResponse.role_name })
        } catch (error) {
            return response(res, 400, { message: error.message })
        }
    }

}

module.exports = new SuperAdminService()