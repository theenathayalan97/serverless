module.exports = (database, Sequelize) => {
    const Address = database.define('address', {
        uuid: {
            type: Sequelize.UUID,
            primaryKey: true,
            defaultValue: Sequelize.UUIDV4,
            // defaultValue: Sequelize.literal('gen_random_uuid()'),
            unique: true,
        },
        address_type: {
            type: Sequelize.STRING,
            allowNull: false
        },
        address1: {
            type: Sequelize.STRING,
            allowNull: false
        },
        address2: {
            type: Sequelize.STRING,
            allowNull: true
        },
        city: {
            type: Sequelize.STRING,
            allowNull: false
        },
        state: {
            type: Sequelize.STRING,
            allowNull: false
        },
        country: {
            type: Sequelize.STRING,
            allowNull: false
        },
        zip_code: {
            type: Sequelize.STRING,
            allowNull: false
        },
        primary_address: {
            type: Sequelize.BOOLEAN,
            allowNull: true
        },
        Secondary_phone: {
            type: Sequelize.STRING,
            allowNull: true
        },
        secondary_email: {
            type: Sequelize.STRING,
            allowNull: true
        },
        is_deleted: {
            type: Sequelize.BOOLEAN,
            allowNull: false
        },
        //foreign key
        user_id: {
            type: Sequelize.UUID,
            allowNull: false
        },
        created_by: {
            type: Sequelize.UUID,
            allowNull: false
        },
        updated_by: {
            type: Sequelize.UUID,
            allowNull: false
        },
    },
        {
            timeStamps: true
        })
    return Address
}