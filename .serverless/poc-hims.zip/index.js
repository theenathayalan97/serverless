const serverless = require("serverless-http");
require(`dotenv`).config();
const bodyParser = require('body-parser')
const express = require('express')
const app = express()
const port = 8080
app.use(bodyParser.json())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
// routes
const userRoute = require(`./route/common/userRoute`);
const tenantRoute = require(`./route/tenant/tenant`);
const roleMaster = require(`./route/common/roleMaster`);
app.use('/api', userRoute)
app.use('/api', roleMaster)
app.use('/api', tenantRoute)

//postgresql connection
if (process.env.databaseConnection == 'postgres') {
    console.log('Postgres connection');
    require("./dbConfig/postgresql");
}

app.listen(port, () => {
    console.log(`App listening at http://localhost:${port}`)
})
var handler = serverless(app);
module.exports = {
    app, handler
};