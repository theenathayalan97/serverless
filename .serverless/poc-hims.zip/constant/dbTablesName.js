const users = 'users'
const roleMaster = 'roleMaster'
const tenant = 'tenant'
const tenantAudit = 'tenant_audit'
const profile = 'profile'
const providerProfiles = 'provider_profiles'
const specialtyMaster = 'specialty_master'
const doctorSpecialty = 'doctor_specialty'
const tenantProfile = 'tenant_profile'
const tenantProfileAudit = 'tenant_profile_audit'
const tenantJsonMaster = 'tenant_json_master'
const JsonMaster = 'json_master'

//export table names
module.exports = {
    users, roleMaster, tenant, profile, specialtyMaster, doctorSpecialty,
    providerProfiles, tenantProfile, tenantProfileAudit, tenantAudit, JsonMaster,
    tenantJsonMaster
}
